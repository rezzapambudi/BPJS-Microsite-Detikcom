
            <!-- Menu Top Bar - Start -->
            <div class="topbar " data-effect="fadeIn">
                <div class="menu">
                    <div class="primary inviewport animated delay4" data-effect="fadeInRightBig">
                        <div class='cssmenu'>
                            <!-- Menu - Start -->
                            <ul class='menu-ul'><li class='has-sub'>
                                <a href='index.php'>Home <i class='mdi'></i></a>
                                
                            </li>
                            <li class='has-sub'>
                                <a href='news.php'>Berita BPJS <i class='mdi'></i></a>
                                
                            </li>
                            <li class='has-sub'>
                                <a href='testimonial.php'>Testimonial <i class='mdi'></i></a>
                                
                            </li>
                            <!--
                            <li class='has-sub'>
                                <a href='#'>Pendaftaran <i class='mdi mdi-chevron-down'></i></a>
                                <ul>
                                    <li>
                                        <a href='portfolio-grid.html'>Grid</a>
                                    </li>
                                    <li>
                                        <a href='portfolio-masonary.html'>Masonary</a>
                                    </li>
                                    <li>
                                        <a href='portfolio-full.html'>Full Page Width</a>
                                    </li>
                                    <li>
                                        <a href='portfolio-grid-2.html'>Grid (2 Column)</a>
                                    </li>
                                </ul>
                            </li>-->
                        </ul>
                        <!-- Menu - End -->
                    </div>
                </div>
                <div class="black inviewport animated delay4" data-effect="fadeInLeftBig">
                    <div class='cssmenu'>
                        <!-- Menu - Start -->
                        <ul class='menu-ul'><li class='has-sub'>
                            <a href='index.php#whatwhyhow'>Blog <i class='mdi'></i></a>
                            
                        </li>
                        <li class='has-sub'>
                            <a href='index.php#contact'>Pendaftaran <i class='mdi'></i></a>
                            
                        </li>
                        
                        <li class='has-sub'>
                            <a href='hadiah.php'>Hadiah <i class='mdi'></i></a>
                            
                        </li>
                        <li class='has-sub'>
                            <a href="#">S &amp; K <i class="mdi mdi-chevron-down"></i></a>
                            <ul>
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#myModal">Syarat &amp; Ketentuan</a>
                                </li>
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#myModal2">Sistem Penjurian</a>
                                </li>
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#myModal3">Periode</a>
                                </li>
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#myModal4">Rekomendasi Tema</a>
                                </li>
                            </ul>
                            
                        </li>
                        <!--
                        <li>
                            <a href='contact.html'>Contact</a>
                        </li>-->
                    </ul>
                    <!-- Menu - End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Menu Top Bar - End -->
    <div class='header-logo-wrap'>
        <div class="container">
            <div class="logo col-xs-2">
                <span><a href="index.php"><img src="img/logo.png" style="max-width:240px;" class="logone"></a></span>
            </div>
            <div class="menu-mobile col-xs-10 pull-right cssmenu">
                <i class="mdi mdi-menu menu-toggle"></i>
                <ul class="menu" id='parallax-mobile-menu'>
                </ul>
            </div>
        </div>
    </div>