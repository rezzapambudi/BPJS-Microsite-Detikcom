<?php
    require_once("header.php");
?>
    <body class=" angled  yellow">
        <?php require_once("modal.php"); ?>
        <!-- Section Start - Header -->
        <section class="header bg-lightgray header-2" >
            <!-- Menu Top Bar - Start -->
            <?php require_once("navbar.php"); ?>
    <!-- Menu Top Bar - End -->
    <!-- Logo and Mobile Menu - Start -->
    
    <!-- Logo and Mobile Menu - End -->
    <!-- Header Slide - Start -->
    <div class="header-slide" style="position:relative;">
        <img alt="header-banner-image" src="img/banner-2alt1.jpg" class='header-img visible-lg visible-md hidden-xs hidden-sm' style=''>
        <img alt="header-banner-image" src="img/banner-2alt.jpg" class='header-img hidden-xs visible-sm' style=''>
        <img alt="header-banner-image" src="img/banner-2alt2.jpg" class='header-img visible-xs hidden-sm' style=''>
        <div class="overlay overlaysmall1">
            <div class="black inviewport animated delay4" data-effect="fadeInLeftOpacity"></div>
            <div class="primary inviewport animated delay4" data-effect="fadeInRightOpacity"></div>
            <!-- Header Text - Start -->
            <div class="maintext">
                <div class="primary-text inviewport animated delay4" data-effect="fadeInRightBig">
                    <div class="left-line" style="background-color: rgba(255, 255, 255, 0.65);">
                        <h4>Berita</h4>
                        <h4>BPJS Ketenagakerjaan</h4>
                    </div>
                </div>
                <!--
                <div class="black-text inviewport animated delay4" data-effect="fadeInLeftBig">
                    <div>
                        <h1>Desk</h1>
                    </div>
                </div>-->
            </div>
            <!-- Header Text - End -->
        </div>
    </div>
    <!-- Header Slide - End -->
</section>
<!-- Section End - Header -->
<!-- Section Start - Blogs -->
 <section class="publicaciones-blog-home" style="background-color:#ffffff;">
    <div class="angled_down_inside lightgray">
        <div class="slope upleft"></div>
        <!--<div class="slope upright"></div>-->
    </div>
      <div class="container">
        <h3 class="heading">Berita BPJS Ketenagakerjaan</h3>
            <div class="headul"></div>
        <div class="">
        
          <!--<h2 style="font-family: 'Reem Kufi', sans-serif;color:#35b51c;">Berita Hijab Hunt</h2>-->
          <div class="row-page row" style="font-family: 'Reem Kufi', sans-serif;padding-top: 76px;">
            <!--
            <div class="col-page col-sm-8 col-md-6">
              <a href="" class="black fondo-publicacion-home">
                <div class="img-publicacion-principal-home">
                  <img class="undefined" src="" style="width: 300px;height: 400px;background-image: url(&quot;img/artikel.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;">
                </div>
                <div class="contenido-publicacion-principal-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>-->
            <div class="col-page col-sm-4 col-md-3">
              <a href=""  class="fondo-publicacion-home">
                <div class="image"><center><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></center></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                  <span class="dates">24 Agustus 2016</span>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                  <div class="image"><center><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel2.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></center></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                  <span class="dates">24 Agustus 2016</span>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href=""  class="fondo-publicacion-home">
                  <div class="image"><center><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></center></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                    <span class="dates">24 Agustus 2016</span>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                  <div class="image"><center><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel2.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></center></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                    <span class="dates">24th August 2016</span>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                  <div class="image"><center><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></center></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                    <span class="dates">24 Agustus 2016</span>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                  <div class="image"><center><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel2.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></center></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                    <span class="dates">24 Agustus 2016</span>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                  <div class="image"><center><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></center></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                    <span class="dates">24 Agustus 2016</span>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                  <div class="image"><center><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel2.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></center></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                    <span class="dates">24 Agustus 2016</span>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <!---
            <div class="col-page col-sm-4 col-md-3">
              <a href="#" class="todas-las-publicaciones-home">
                  <span>Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</span>
              </a>
            </div>-->
          </div>
          <div style="margin-top: 70px;">
            <center>
            
            
                <ul class="pagination">
                    <li><a href="#">&laquo;</a></li>
                    <li><a href="#">1</a></li>
                    <li class="active"><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                    <li><a href="#">&raquo;</a></li>
                </ul>
            
        
            </center>
        </div>  
        </div>
      </div>
     
    </div>
    <!-- Angled Section - Start -->
    <div class="angled_up_inside white">
        <div class="slope upleft"></div>
        <div class="slope upright"></div>
    </div>
    </section>
        

<!-- Section End - Blogs -->
<!-- Section Start - Footer -->
<?php require_once("footer2.php");?>
<!-- Section End - Footer -->
</body>
</html>