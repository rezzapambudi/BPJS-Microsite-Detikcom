
    <section class="publicaciones-blog-home" style="background-color:#ffffff;">
    <div class="angled_down_inside lightgray">
        <div class="slope upleft"></div>
        <div class="slope upright"></div>
    </div>
      <div class="container">
        <h3 class="heading">Berita BPJS</h3>
            <div class="headul"></div>
        <div class="">
        
          <!--<h2 style="font-family: 'Reem Kufi', sans-serif;color:#35b51c;">Berita Hijab Hunt</h2>-->
          <div class="row-page row" style="font-family: 'Reem Kufi', sans-serif;padding-top: 76px;">
            <div class="col-page col-sm-8 col-md-6">
              <a href="" class="black fondo-publicacion-home">
                <div class="img-publicacion-principal-home">
                  <img class="undefined" src="" style="width: 300px;height: 400px;background-image: url(&quot;img/artikel.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;">
                </div>
                <div class="contenido-publicacion-principal-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href=""  class="fondo-publicacion-home">
                <div class="image"><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                <div class="image"><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel2.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                <div class="image"><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="hidden-sm col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                <div class="image"><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel2.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="hidden-sm col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                <div class="image"><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;img/artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</h4>
                  <p>Jaminan Hari Tua (JHT) BPJS Ketenagakerjaan atau yang dulu disebut Jamsostek tengah ramai menjadi perbincangan.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="#" class="todas-las-publicaciones-home">
                  <span>Melihat Aturan Baru JHT BPJS Ketenagakerjaan Yang Ramai Diperbincangkan</span>
              </a>
            </div>
          </div>
          <div style="margin-top: 70px;">
            <center>
            <a class="btn btn-primary text-on-primary" href="news.php" style="background-color: #51b974;">Baca Berita Lainnya</a>
            </center>
        </div>  
        </div>
      </div>
    </section>